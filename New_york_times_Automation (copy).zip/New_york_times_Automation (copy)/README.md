(1) For installing packages:
    in pycharm use   pip install -r requirements.txt


(2) requirements.txt:
    contain packages for this task to install 

(3) main.py::
   contain methods of  our class which 
   do our task 

(4)tasks.py ::
   contain the  Class which defined necessary 
   function for this task 



# nyt
