search_button_selector_xpath = "//button[@data-testid='search-button']"
search_input_selector_xpath = "//input[@data-testid='search-input']"
submit_button_selector_xpath = "//button[@data-testid='search-submit']"
date_range_dropdown_selector_xpath = "//button[@data-testid='search-date-dropdown-a']"
date_range_options_locator_xpath = '//ul[contains(@class, "css-vh8n2n")]//li'
start_date_input_selector_xpath = "//input[@data-testid='DateRange-startDate']"
end_date_input_selector_xpath = "//input[@data-testid='DateRange-endDate']"
category_type_selector_xpath = '//ul[@data-testid="multi-select-dropdown-list"]//li'
select_category_section_xpath = '//ul[@data-testid="multi-select-dropdown-list"]//li'
show_more_button_selector_xpath = '//button[@data-testid="search-show-more-button"]'
sort_by_selector_xpath = '//select[@data-testid="SearchForm-sortBy"]'
