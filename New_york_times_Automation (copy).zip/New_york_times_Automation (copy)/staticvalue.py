browser_url = 'https://www.nytimes.com'
data_sheet = 'Data'
image_sheet = 'Image'
header_data_sheet = ["Date", "Region", "Title", "Description", "Authors", "Image URL"]
workbook_path = 'output/search_results.xlsx'
files_output_path = 'output/download_images'
images_path = 'output/download_images/image_'
log_file_path = "output/bot_task_log.log"
