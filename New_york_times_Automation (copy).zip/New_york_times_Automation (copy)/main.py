from tasks import Bot

run = Bot()
run.search()
run.select_sorting()
run.select_date_range()
run.select_section_category()
run.numbers = []
run.select_type_category()
run.click_show_more()
run.save_search_results()
